#include <stdio.h>
#include <stdlib.h>


void sort(struct topleaf topleafs[N]);
